const os = require("os");
const path = require("path");

const HOME = os.homedir();

module.exports = {
  apps: [
    {
      name: "zylos-weixin",
      script: "dist/bot.js",
      cwd: path.join(HOME, "zylos/.claude/skills/weixin"),
      interpreter: "node",
      node_args: "",
      autorestart: true,
      max_restarts: 10,
      restart_delay: 5000,
      watch: false,
      env: {
        NODE_ENV: "production",
      },
      error_file: path.join(HOME, "zylos/components/weixin/logs/error.log"),
      out_file: path.join(HOME, "zylos/components/weixin/logs/out.log"),
      merge_logs: true,
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
    },
  ],
};
